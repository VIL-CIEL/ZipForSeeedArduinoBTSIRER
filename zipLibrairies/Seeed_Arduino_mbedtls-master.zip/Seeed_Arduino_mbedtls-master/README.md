# Seeed_Arduino_mbedtls  [![Build Status](https://travis-ci.com/Seeed-Studio/Seeed_Arduino_mbedtls.svg?branch=master)](https://travis-ci.com/Seeed-Studio/Seeed_Arduino_mbedtls)

Please note that you need to use the following release versions for the respective firmware structures:

- v2.0.1 - AT firmware structure
- v3.0.1 and above - eRPC firmware structure
